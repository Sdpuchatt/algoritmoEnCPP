#include <iostream>
using namespace std;

int main() {
 system("cls");
 double decimal1 = 12.45;
 double decimal2 = 3.3;
 int entero1 = 10;
 int entero2 = 2;

   cout << entero1/entero2 << endl;
   cout << entero1/decimal2 << endl;
   cout << decimal1/decimal2 << endl;
   cout << decimal1/entero2 << endl;
   return 0;
}
