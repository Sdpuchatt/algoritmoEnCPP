// b. Realizar un programa que pida 3 datos y nos devuelva el promedio
#include <iostream>
using namespace std;

int main() // main() es donde empieza la ejecución
{
  double num1 = 0,num2 = 0,num3 = 0;
   cout << "Vamos a promediar los 3 numeros que ingrese por consola. " << endl;
   cout << "Ingrese el primer numero " << endl;
   cin >> num1;
   cout << "introduzca Segundo numero " << endl;
   cin >> num2;
   cout << "falta el ultimo numero " << endl;
   cin >> num3;
    cout << "El promedio de los numeros es : "<< (num1+num2+num3)/3 << endl;
   return 0;
}

// c. Realizar un programa que pida 4 datos y devuelva el producto de Ambos
#include <iostream>
using namespace std;



