// d. Escribe un programa en C++ que nos diga cuál es el volumen de un cono con
// un radio de la base de 14,5 y una altura de 26,79. La fórmula que debes usar
// es: (PI * Radio al cuadrado * altura)/3 Recuerda que el valor (aproximado) de
// ԉ es 3,141592.

#include <iostream>
using namespace std;

int main() // main() es donde empieza la ejecución
{
   cout << "El volumen de un cono con radio: 14,5 y altura: 26,79 es " << (14.5*26.79*3.141592)/3<< "mts cubicos"<< endl;
   return 0;
}
