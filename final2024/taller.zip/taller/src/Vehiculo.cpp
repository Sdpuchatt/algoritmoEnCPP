// Vehiculo.cpp
#include "../include/Vehiculo.hpp"

Vehiculo::Vehiculo(string color, string marca) : color(color), marca(marca) {}
